package com.example.listadesignos;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private TextView encabezado;
    private ListView listaZodiaco;
    private TextView info;
    private Button salir;

    private String signos[] = {"Aries", "Tauro",
            "Géminis", "Cáncer",
            "Leo", "Virgo",
            "Libra", "Escorpio",
            "Sagitario", "Capricornio",
            "Acuario", "Piscis"};

    private String periodos[] = {"21-Mar, 19-Abr", "20-Abr, 20-May",
            "21-May, 20-Jun", "21-Jun, 22-Jul",
            "23-Jul, 22-Ago", "23-Ago, 22-Sep",
            "23-Sep, 22-Oct", "23-Oct, 21-Nov",
            "22-Nov, 21-Dic", "22-Dic, 19-Ene",
            "20-Ene, 18-Feb", "19-Feb, 20-Mar"};

    private String informacion[] = {
            "Aries ♈: " + "Tu fuego interior está más vivo que nunca 🔥.\nEste año llegarán retos épicos para ti.\n🌟 Atrévete a salir de tu zona de confort.\nConfía en tu instinto para triunfar. 🏆",

            "Tauro ♉: " + "Este ciclo traerá estabilidad y nuevas raíces 🌱.\nTus esfuerzos darán frutos inesperados.\n💎 En el amor, alguien especial se acerca.\nInvierte en ti mismo y en tus sueños. 💖",

            "Géminis ♊: " + "Ideas nuevas cruzan tu mente como rayos ⚡.\nEste año, cada conversación abrirá puertas.\n📚 El aprendizaje será tu mejor arma.\nConfía en tu ingenio y creatividad. 🎨",

            "Cáncer ♋: " + "Vibras de sanación te envuelven este año 🧘‍♀️.\nCerrarás ciclos para abrir otros aún mejores.\n🏡 Cuida tus vínculos más cercanos.\nConfía en tu corazón, sabe el camino. 💓",

            "Leo ♌: " + "Tu luz brillará más que nunca este ciclo ✨.\nGrandes logros personales te esperan.\n👑 Recibirás admiración genuina.\nCelebra cada paso con gratitud y orgullo. 🎉",

            "Virgo ♍: " + "Organización y éxito se toman tu vida 📋.\nTendrás la oportunidad de crecer profesionalmente.\n📈 Delega más, confía en tu equipo.\nCuida tu bienestar físico y mental. 🧠💪",

            "Libra ♎: " + "Tu encanto será magnético este año ✨.\nSerás el puente que conecta corazones.\n💞 Nuevos comienzos en amor y amistades.\nElige tu paz antes que la perfección. ☁️",

            "Escorpio ♏: " + "Transformación profunda en tu horizonte 🔥.\nRompe viejas cadenas, renace más fuerte.\n🦂 Tu intuición te guiará a nuevos caminos.\nAtrévete a seguir tu pasión sin miedos. 🚀",

            "Sagitario ♐: " + "La aventura llama a tu puerta 🌍.\nNuevos viajes y aprendizajes te esperan.\n🎯 Tu optimismo será tu brújula.\nAbre tu mente y corazón a lo inesperado. 🌟",

            "Capricornio ♑: " + "Es tu momento de construir imperios 🏛️.\nTus metas serán más claras que nunca.\n🚀 El esfuerzo constante traerá éxito.\nRecuerda disfrutar también el presente. 🎈",

            "Acuario ♒: " + "Innovaciones y sorpresas llenarán tu año 💡.\nTu autenticidad será tu mejor herramienta.\n🌈 Nuevos grupos y amistades te enriquecerán.\nSueña grande, los límites son ilusorios. 🛸",

            "Piscis ♓: " + "Sueños y realidades se entrelazan este año 🌊.\nLa inspiración será tu brújula diaria.\n🎶 Tu intuición abrirá nuevos caminos.\nCree en la magia de tus propios pasos. 🧚‍♂️"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        encabezado = findViewById(R.id.textView);
        listaZodiaco = findViewById(R.id.listView);
        info = findViewById(R.id.acercaDe);
        salir = findViewById(R.id.button);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item_signo, signos);

        listaZodiaco.setAdapter(adapter);

        listaZodiaco.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                encabezado.setText("Periodo " + periodos[i]);
                info.setText("" + informacion[i]);
            }
        });

        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
    }


}

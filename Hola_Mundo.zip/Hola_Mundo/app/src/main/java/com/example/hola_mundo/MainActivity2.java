package com.example.hola_mundo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    private EditText editText2;
    private Button button3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);

        Bundle bundle = this.getIntent().getExtras();
        button3 = findViewById(R.id.Button3);
        editText2 = findViewById(R.id.EditText2);

        String nombre = bundle.getString("nombre" );
        String aP = bundle.getString("apellidoP" );
        String aM = bundle.getString("apellidoM" );

        editText2.setText(nombre + " " + aP + " " + aM );

        button3.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(
                                MainActivity2.this, com.example.hola_mundo.MainActivity.class
                        );
                        startActivity(intent);
                    }
                }
        );
    }
}
package com.example.hola_mundo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editText1;
    private EditText editText11;
    private EditText editText111;
    private Button button1;
    private Button button2;

    @Override //como si fuera el constructor
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); //llamado al padre
        setContentView(R.layout.activity_main); //dibuja el hml

        //unimos los componentes del lado de Java con las de la vista.xml
        editText1 = findViewById(R.id.EditText1);
        editText11 = findViewById(R.id.EditText11);
        editText111 = findViewById(R.id.EditText111);
        button1 = findViewById(R.id.Button1);
        button2 = findViewById(R.id.Button2);

        button1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String nombre = editText1.getText().toString();
                        String apeP = editText11.getText().toString();
                        String apeM = editText111.getText().toString();

                        Bundle bundle = new Bundle();
                        bundle.putString("nombre", nombre ); // es un diccionario, trae una llave y un valor
                        bundle.putString("apellidoP", apeP); // es un diccionario, trae una llave y un valor
                        bundle.putString("apellidoM", apeM); // es un diccionario, trae una llave y un valor
                        // va a recibir dos parametros, su propia clase a la otra clase
                        Intent intent = new Intent(
                                MainActivity.this, MainActivity2.class );
                        //ahora se monta el paquete "bundle", que trae el nombre
                        intent.putExtras(bundle);
                        startActivity(intent); //se destruye y llama al mainactivity2, cambio de pantalla
                    }
                }
        );

        //Accion del Boton 2
        button2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        System.exit(0);
                    }
                }
        );

    }
}

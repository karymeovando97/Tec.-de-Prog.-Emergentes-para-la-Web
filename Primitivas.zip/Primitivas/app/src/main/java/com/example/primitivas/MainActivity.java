package com.example.primitivas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Vista vista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout layout = findViewById(R.id.layoutPrincipal);
        vista = new Vista(this);
        layout.addView(vista);

        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);

        button1.setOnClickListener(v -> vista.cambiarColor(Color.BLUE));
        button2.setOnClickListener(v -> vista.cambiarColor(Color.RED));
        button3.setOnClickListener(v -> vista.cambiarColor(Color.GREEN));
    }

    class Vista extends View {
        float x, y;
        String accion = "accion";
        Path pathActual = new Path();
        Paint paintActual = new Paint();

        class Dibujo {
            Path path;
            Paint paint;

            Dibujo(Path path, Paint paint) {
                this.path = path;
                this.paint = new Paint(paint);
            }
        }

        ArrayList<Dibujo> dibujos = new ArrayList<>();

        public Vista(Context context) {
            super(context);
            paintActual.setStyle(Paint.Style.STROKE);
            paintActual.setStrokeWidth(5);
            paintActual.setColor(Color.BLUE);
        }

        public void cambiarColor(int nuevoColor) {
            dibujos.add(new Dibujo(pathActual, paintActual));
            pathActual = new Path();
            paintActual = new Paint(paintActual);
            paintActual.setColor(nuevoColor);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            for (Dibujo dibujo : dibujos) {
                canvas.drawPath(dibujo.path, dibujo.paint);
            }
            canvas.drawPath(pathActual, paintActual);
        }

        @Override
        public boolean onTouchEvent(MotionEvent motionEvent) {
            x = motionEvent.getX();
            y = motionEvent.getY();

            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                accion = "down";
                pathActual.moveTo(x, y);
            }
            if (motionEvent.getAction() == MotionEvent.ACTION_MOVE) {
                accion = "move";
                pathActual.lineTo(x, y);
            }

            invalidate();
            return true;
        }
    }
}
package com.example.acelerometro;

import androidx.appcompat.app.AppCompatActivity;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView txtCoordenadaX, txtCoordenadaY, txtCoordenadaZ;
    private TextView minX, minY, minZ, maxX, maxY, maxZ;
    private float actualX = 0, actualY = 0, actualZ = 0;
    private float minValorX = Float.MAX_VALUE, minValorY = Float.MAX_VALUE, minValorZ = Float.MAX_VALUE;
    private float maxValorX = Float.MIN_VALUE, maxValorY = Float.MIN_VALUE, maxValorZ = Float.MIN_VALUE;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        txtCoordenadaX = findViewById(R.id.txtCoordenadaX);
        txtCoordenadaY = findViewById(R.id.txtCoordenadaY);
        txtCoordenadaZ = findViewById(R.id.txtCoordenadaZ);

        minX = findViewById(R.id.minX);
        minY = findViewById(R.id.minY);
        minZ = findViewById(R.id.minZ);
        maxX = findViewById(R.id.maxX);
        maxY = findViewById(R.id.maxY);
        maxZ = findViewById(R.id.maxZ);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensors = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if (sensors.size() > 0) {
            sensorManager.registerListener(this, sensors.get(0), SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override
    protected void onStop() {
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override
    public void onSensorChanged(SensorEvent event){
        synchronized (this) {
            actualX = event.values[0];
            actualY = event.values[1];
            actualZ = event.values[2];

            txtCoordenadaX.setText("Valor de X: " + String.format("%.2f", actualX));
            txtCoordenadaY.setText("Valor de Y: " + String.format("%.2f", actualY));
            txtCoordenadaZ.setText("Valor de Z: " + String.format("%.2f", actualZ));

            // Actualizar mínimos
            if (actualX < minValorX) minValorX = actualX;
            if (actualY < minValorY) minValorY = actualY;
            if (actualZ < minValorZ) minValorZ = actualZ;

            // Actualizar máximos
            if (actualX > maxValorX) maxValorX = actualX;
            if (actualY > maxValorY) maxValorY = actualY;
            if (actualZ > maxValorZ) maxValorZ = actualZ;

            // Mostrar en la tabla
            minX.setText(String.format("%.2f", minValorX));
            minY.setText(String.format("%.2f", minValorY));
            minZ.setText(String.format("%.2f", minValorZ));

            maxX.setText(String.format("%.2f", maxValorX));
            maxY.setText(String.format("%.2f", maxValorY));
            maxZ.setText(String.format("%.2f", maxValorZ));
        }
    }
}
